public class HangingMan {

    private int numWrongGuesses;

    String[] HangmanImage = {"Darth Vadar has not formed yet, prevent Darth Vadar from evolving.",
            "                       .-.\n" +
                    "                      |_:_|\n" +
                    "                     /(_Y_)\\\n" +
                    "                    ( \\/M\\/ )\n" +
                    "                  _.'-/'-'\\-'._\n"+
                    "Darth Vadar is in his first form, prevent Darth Vadar from evolving",

            "                       .-.\n" +
                    "                      |_:_|\n" +
                    "                     /(_Y_)\\\n" +
                    "                    ( \\/M\\/ )\n" +
                    "                  _.'-/'-'\\-'._\n" +
                    "                _/.--'[[[[]'--.\\_\n" +
                    "               /_'  : |::\"| :  '.\\\n" +
                    "              //   ./ |oUU| \\.'  :\\\n" +
                    "             _:'..' \\_|___|_/ :   :|\n" +
                    "Darth Vadar is in his second form, prevent Darth Vadar from evolving",

            "\n" +
                    "\n" +
                    "                       .-.\n" +
                    "                      |_:_|\n" +
                    "                     /(_Y_)\\\n" +
                    "                    ( \\/M\\/ )\n" +
                    "                  _.'-/'-'\\-'._\n" +
                    "                _/.--'[[[[]'--.\\_\n" +
                    "               /_'  : |::\"| :  '.\\\n" +
                    "              //   ./ |oUU| \\.'  :\\\n" +
                    "             |:'..' \\_|___|_/ :   :|\n" +
                    "             /   .'  |_[___]_|  :.':\\\n" +
                    "            / ::\\ |  :  | |  :   ; : \\\n" +
                    "             '-'   \\/'.| |.' \\  .;.' |\n" +
                    "             |\\_    \\  '-'   :       |\n" +
                    "             |  \\    \\ .:    :   |   |\n" +
                    "             |   \\    | '.   :    \\  |\n"+
                    "Darth Vadar is in his third form, prevent Darth Vadar from evolving",
            "                       .-.\n" +
                    "                      |_:_|\n" +
                    "                     /(_Y_)\\\n" +
                    "                    ( \\/M\\/ )\n" +
                    "                  _.'-/'-'\\-'._\n" +
                    "                _/.--'[[[[]'--.\\_\n" +
                    "               /_'  : |::\"| :  '.\\\n" +
                    "              //   ./ |oUU| \\.'  :\\\n" +
                    "             |:'..' \\_|___|_/ :   :|\n" +
                    "             /   .'  |_[___]_|  :.':\\\n" +
                    "            / ::\\ |  :  | |  :   ; : \\\n" +
                    "             '-'   \\/'.| |.' \\  .;.' |\n" +
                    "             |\\_    \\  '-'   :       |\n" +
                    "             |  \\    \\ .:    :   |   |\n" +
                    "             |   \\    | '.   :    \\  |\n" +
                    "             /       \\   :. .;       |\n" +
                    "            /     |   |  :__/     :  \\\\\n" +
                    "           |  |   |    \\:   | \\   |   ||\n" +
                    "          /    \\  : :  |:   /  |__|   /|\n" +
                    "          |     : : :_/_|  /'._\\  '--|_\\\n" +
                    "          /___.-/_|-'   \\  \\\n" +
                    "                         '-'\n"+
                    "Darth Vadar is in his fourth form, prevent Darth Vadar from evolving",
            "                       .-.\n" +
                    "                      |_:_|\n" +
                    "                     /(_Y_)\\\n" +
                    ".                   ( \\/M\\/ )\n" +
                    " '.               _.'-/'-'\\-'._\n" +
                    "   ':           _/.--'[[[[]'--.\\_\n" +
                    "     ':        /_'  : |::\"| :  '.\\\n" +
                    "       ':     //   ./ |oUU| \\.'  :\\\n" +
                    "         ':  _:'..' \\_|___|_/ :   :|\n" +
                    "           ':.  .'  |_[___]_|  :.':\\\n" +
                    "            [::\\ |  :  | |  :   ; : \\\n" +
                    "             '-'   \\/'.| |.' \\  .;.' |\n" +
                    "             |\\_    \\  '-'   :       |\n" +
                    "             |  \\    \\ .:    :   |   |\n" +
                    "             |   \\    | '.   :    \\  |\n" +
                    "             /       \\   :. .;       |\n" +
                    "            /     |   |  :__/     :  \\\\\n" +
                    "           |  |   |    \\:   | \\   |   ||\n" +
                    "          /    \\  : :  |:   /  |__|   /|\n" +
                    "          |     : : :_/_|  /'._\\  '--|_\\\n" +
                    "          /___.-/_|-'   \\  \\\n" +
                    "                         '-'\n"+
                    "Darth Vadar is in his final form, you have one last chance before being slain",
    };


    public boolean isntDead(){
        return numWrongGuesses < 6;
    }
    public void show(){
        System.out.println(HangmanImage[numWrongGuesses]);
    }
    public void dieSomeMore(){
        numWrongGuesses++;
    }
}
