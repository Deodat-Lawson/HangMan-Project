import java.util.*;
import java.io.*;

public class Puzzle
{

    private ArrayList<String> allWords = new ArrayList<>();
    private HashSet<String> guessedW = new HashSet<>();
    private String currWord = "";
    private String guessedWord = "";

    public Puzzle() throws IOException{
        BufferedReader br = new BufferedReader(new FileReader("words.in"));
        String a = br.readLine();
        while(a != null){
            allWords.add(a);
            a = br.readLine();
        }
        br.close();
        genNewWord();
    }


    public void genNewWord(){
        currWord = allWords.get((int)(Math.random()*allWords.size()));
        for (int i = 0; i < currWord.length(); i++) {
            guessedWord+="_";
        }
    }
    public boolean isUnsolved(){
        return !(guessedWord.equals(currWord));
    }

    public void show(){
        System.out.println();
        for (int i = 0; i < currWord.length(); i++) {
            System.out.print(guessedWord.substring(i,i+1).toUpperCase()+" ");
        }
        System.out.println();
        System.out.print("Guessed Words"+" ");
        for (String a:guessedW
             ) {
            System.out.print(a.toUpperCase()+", ");
        }
    }

    public boolean makeGuess(String guess){
        guess = guess.toLowerCase();
        guessedW.add(guess);
        boolean flag = false;
        for (int i = 0; i < currWord.length(); i++) {
            if(currWord.substring(i,i+1).equals(guess)){
                guessedWord = guessedWord.substring(0,i)+currWord.substring(i,i+1)+guessedWord.substring(i+1);
                flag = true;
            }
        }
        return flag;
    }

    public String getWord(){
        return "\"" +currWord+"\"";
    }






}
