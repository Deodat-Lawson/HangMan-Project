import java.util.*;
import java.io.*;
public class Main
{
    public static void main(String[] args) throws IOException{
        Scanner scanner = new Scanner(System.in);

        HangingMan hangingMan = new HangingMan();
        Puzzle puzzle = new Puzzle();

        System.out.println("You met Darth Vadar, you need to guess the word before he evolves, prevent Darth Vadar from evolving.");
        while (puzzle.isUnsolved() && hangingMan.isntDead()) {
            hangingMan.show();
            puzzle.show();
            System.out.print("\nMake a guess: ");
            String guess = scanner.nextLine();
            if (!puzzle.makeGuess(guess)) {
                hangingMan.dieSomeMore();
            }
            clearScreen();
        }

        if (hangingMan.isntDead()) {
            System.out.println("_____.___.               __      __.__        \n" +
                    "\\__  |   | ____  __ __  /  \\    /  \\__| ____  \n" +
                    " /   |   |/  _ \\|  |  \\ \\   \\/\\/   /  |/    \\ \n" +
                    " \\____   (  <_> )  |  /  \\        /|  |   |  \\\n" +
                    " / ______|\\____/|____/    \\__/\\  / |__|___|  /\n" +
                    " \\/                            \\/          \\/ ");
            System.out.println();
            System.out.println("The word was " + puzzle.getWord());
        } else {
            System.out.println("_____.___.              .____                        \n" +
                    "\\__  |   | ____  __ __  |    |    ____  ______ ____  \n" +
                    " /   |   |/  _ \\|  |  \\ |    |   /  _ \\/  ___// __ \\ \n" +
                    " \\____   (  <_> )  |  / |    |__(  <_> )___ \\\\  ___/ \n" +
                    " / ______|\\____/|____/  |_______ \\____/____  >\\___  >\n" +
                    " \\/                             \\/         \\/     \\/ ");
            System.out.println();
            System.out.println("The word was " + puzzle.getWord());
        }
    }

    public static void clearScreen() {
        System.out.println("\f");
    }



}


